# XXKey Linux Port

Thư mục này chứa mã nguồn và lõi xử lý được biên dịch sẵn của bộ gõ XXKey dành cho Linux.

## Yêu cầu hệ thống:
- Đã cài đặt Rust (cargo/rustc) trên Linux.

## Hướng dẫn cài đặt & biên dịch:
1. Chạy lệnh: `chmod +x build.sh && ./build.sh`
2. Sau khi biên dịch hoàn tất, hai file thực thi sẽ được tạo tại:
   - `src/target/release/xxkey-daemon` (Chương trình gõ phím IBus/Fcitx5 chạy ẩn)
   - `src/target/release/xxkey-settings` (Giao diện cấu hình bộ gõ Slint)
