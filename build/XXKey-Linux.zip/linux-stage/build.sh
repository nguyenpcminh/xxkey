#!/bin/bash
set -e
echo "=============================================="
echo "Building XXKey Daemon & Settings UI for Linux"
echo "=============================================="
cd src
cargo build --release -p platform-linux -p ui-settings
echo
echo "Build complete! Executables can be found in:"
echo "  src/target/release/xxkey-daemon"
echo "  src/target/release/xxkey-settings"
echo "=============================================="
