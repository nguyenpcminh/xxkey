@echo off
echo ==============================================
echo Building XXKey Daemon & Settings UI for Windows
echo ==============================================
cd src
cargo build --release -p platform-win -p ui-settings
echo.
echo Build complete! Executables can be found in:
echo   src\target\release\xxkey-daemon.exe
echo   src\target\release\xxkey-settings.exe
echo ==============================================
pause
