# XXKey Windows Port

Thư mục này chứa mã nguồn và lõi xử lý được biên dịch sẵn của bộ gõ XXKey dành cho Windows.

## Yêu cầu hệ thống:
- Đã cài đặt Rust (cargo/rustc) trên Windows.

## Hướng dẫn cài đặt & biên dịch:
1. Nhấp đúp chuột vào file `build.bat` để tự động biên dịch.
2. Sau khi biên dịch hoàn tất, hai file thực thi sẽ được tạo tại:
   - `src\target\release\xxkey-daemon.exe` (Chương trình gõ phím chạy ẩn dưới khay hệ thống)
   - `src\target\release\xxkey-settings.exe` (Giao diện cấu hình bộ gõ Slint)
